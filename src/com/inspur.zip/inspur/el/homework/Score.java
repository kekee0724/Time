package com.inspur.el.homework;

/**
 * ѧ��������javabean
 * 
 * @author
 * 
 */
public class Score {
	private double chinese;
	private double math;
	private double english;
	private double computer;
	private double music;

	public double getChinese() {
		return chinese;
	}

	public void setChinese(double chinese) {
		this.chinese = chinese;
	}

	public double getMath() {
		return math;
	}

	public void setMath(double math) {
		this.math = math;
	}

	public double getEnglish() {
		return english;
	}

	public void setEnglish(double english) {
		this.english = english;
	}

	public double getComputer() {
		return computer;
	}

	public void setComputer(double computer) {
		this.computer = computer;
	}

	public double getMusic() {
		return music;
	}

	public void setMusic(double music) {
		this.music = music;
	}

}
